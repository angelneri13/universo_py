from distutils.core import setup 

setup(
	name = "universo_py",
	packages = ["package"],
	version = "0.1",
	description = "Este paquete contiene clases sobre objetos del universo", 
	author = "Ángel Neri",
	author_email = "angelneri13gnu@gmail.com"



	)