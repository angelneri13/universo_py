from .agujero_negro import Agujero_negro
from .estrella import  Estrella
from .planeta import Planeta