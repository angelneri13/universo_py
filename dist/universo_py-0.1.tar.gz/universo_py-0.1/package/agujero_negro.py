class Agujero_negro:
	def __init__(self,tamaño = 0,carga = False, edad = 0, masa = 0):
		self.tamaño = tamaño
		self.carga = carga
		self.edad = edad
		self.masa = masa
	
