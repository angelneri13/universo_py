class Estrella:
	def __init__(self,galaxia ="none",temperatura = 0,masa = 0):
		self.galaxia = galaxia
		self.temperatura = temperatura
		self.masa = masa


